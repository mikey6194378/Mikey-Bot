import { Client } from 'meowsab';
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";
import sub from './sub.js';

const normalizePhoneNumber = (value) => String(value || "").replace(/\D/g, "");
const phoneNumber = normalizePhoneNumber(process.env.BOT_PHONE_NUMBER);
const ownerNumbers = [...new Set(
  String(process.env.BOT_OWNER_NUMBERS || "")
    .split(/[,\n]/)
    .map(normalizePhoneNumber)
    .filter(Boolean)
)];

if (!/^\d{7,15}$/.test(phoneNumber)) {
  throw new Error("Set BOT_PHONE_NUMBER to a valid international phone number in Replit Secrets.");
}
if (ownerNumbers.length === 0 || ownerNumbers.some((number) => !/^\d{7,15}$/.test(number))) {
  throw new Error("Set BOT_OWNER_NUMBERS to one or more valid international phone numbers in Replit Secrets.");
}

/* =========== Client ========== */
const client = new Client({
  phoneNumber,
  prefix: [".", "/", "!", "#"],
  fromMe: null,
  showLogs: false,
  printQR: false,
  owners: ownerNumbers.map((number, index) => ({
    name: `Owner ${index + 1}`,
    jid: `${number}@s.whatsapp.net`,
    lid: ""
  })),
  settings: { noWelcome: true },
  commandsPath: './plugins',
  onError: (error) => {
    console.error("[MeowSab error]", error?.stack || error);
  }
});

client.onGroupEvent(group);
client.onCommandAccess(access);

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

/* =========== Config ========== */
const { config } = client;
config.info = { 
  nameBot: "𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻", 
  nameChannel: "𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑪𝑯𝑨𝑵𝑵𝑬𝑳", 
  idChannel: "120363397941013495@newsletter",
  urls: {
    repo: "https://github.com/deveni0/Pomni-AI",
    api: "https://emam-api.web.id",
    channel: "https://whatsapp.com/channel/0029VbDpCx52ER6frzQ1lc0q"
  },
  copyright: { 
    pack: '𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻', 
    author: '𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻'
  },
  images: [
    "https://files.catbox.moe/byc2tt.jpg"
  ]
};

/* =========== Start ========== */
const startClient = () => {
  let pairingAttempts = 0;
  let pairingIssued = false;
  let connectionOpen = false;
  let connectionListenerAttached = false;
  let observedSocket = null;

  const attachMessageDiagnostics = () => {
    if (!client.sock || client.sock === observedSocket) return;
    observedSocket = client.sock;

    client.sock.ev.on("messages.upsert", ({ messages = [], type }) => {
      const summary = messages.map((message) => ({
        type,
        fromMe: Boolean(message.key?.fromMe),
        hasPayload: Boolean(message.message),
        hasText: Boolean(
          message.message?.conversation ||
          message.message?.extendedTextMessage?.text ||
          message.message?.imageMessage?.caption ||
          message.message?.videoMessage?.caption
        ),
      }));

      console.log("Received message:", JSON.stringify({
        count: summary.length,
        messages: summary,
      }));
    });

    console.log("Message event listener attached.");
  };

  const issuePairingCode = async () => {
    if (pairingIssued || connectionOpen || pairingAttempts >= 15) return;

    if (!client.sock) {
      console.log("Waiting for the WhatsApp socket before requesting pairing.");
      setTimeout(issuePairingCode, 2000);
      return;
    }

    attachMessageDiagnostics();

    if (!connectionListenerAttached) {
      client.sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          connectionOpen = true;
          console.log("[WhatsApp] connection open.");
        }

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          connectionOpen = false;
          console.error(
            `[WhatsApp] connection closed${statusCode ? ` (status ${statusCode})` : ""}.`,
          );
        }
      });
      connectionListenerAttached = true;
    }

    const socketReadyState = client.sock.ws?.readyState;
    if (socketReadyState !== undefined && socketReadyState !== 1) {
      setTimeout(issuePairingCode, 2000);
      return;
    }

    pairingAttempts += 1;
    console.log(`Requesting WhatsApp pairing code (attempt ${pairingAttempts}).`);
    try {
      const issuedCode = await client.sock.requestPairingCode(phoneNumber);
      pairingIssued = true;
      console.log(`WhatsApp pairing code: ${issuedCode}`);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      console.error(`WhatsApp pairing request failed: ${reason}`);
      if (pairingAttempts < 15) {
        setTimeout(issuePairingCode, 2000);
      } else {
        console.error("Unable to issue a WhatsApp pairing code. Check the account number in Replit Secrets.");
      }
    }
  };

  setTimeout(issuePairingCode, 2500);

  try {
    console.log("Starting WhatsApp client.");
    const startResult = client.start();
    Promise.resolve(startResult).catch(() => {
      console.error("Unable to start the WhatsApp client.");
    });
  } catch {
    console.error("Unable to start the WhatsApp client.");
  }
};

startClient();

setTimeout(async () => {
  try {
    const stats = client.commandSystem?.getStats?.();
    if (stats) {
      console.log(
        `Loaded ${stats.total} commands successfully from ${stats.files} plugin files.`,
      );
    } else {
      console.error("Command system is unavailable; no commands are available yet.");
    }

    if (client.commandSystem) {
      await sub(client);
    } else {
      console.error("Command system is unavailable; plugins were not started.");
    }
  } catch (error) {
    console.error("[Plugin startup error]", error?.stack || error);
  }
}, 2000);


/* =========== Catch Errors ========== */
process.on('uncaughtException', (e) => {
    if (e.message.includes('rate-overlimit')) return;
    console.error('[Uncaught Exception]', e?.stack || e);
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err)
});


/* 
=========== Memory Monitor ========== 

setInterval(() => {
    const used = process.memoryUsage().rss / 1024 / 1024
    if (used > 800) {
        console.log(`🔄 Bot memory full (${used.toFixed(1)}MB), restarting...`)
        process.exit(1) 
    }
}, 300_000) 

*/