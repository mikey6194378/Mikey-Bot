import { exec } from "child_process";
import fs from "fs";
import path from "path";
import { promisify } from "util";
import axios from "axios";
import FormData from "form-data";
import { fileTypeFromBuffer } from "file-type";
import { Sticker } from "wa-sticker-formatter";
import cheerio from "cheerio";

const execAsync = promisify(exec);
const tmp = path.join(process.cwd(), "tmp");

if (!fs.existsSync(tmp)) fs.mkdirSync(tmp, { recursive: true });

const createSticker = async (buffer, options = {}) => {
  const sticker = new Sticker(buffer, {
    pack: options.pack || "ڤـ ـ VA ـ ـا",
    author: options.author || "VA",
    type: "full",
    quality: options.mime === "image/jpg" ? 100 : 10,
  });
  return sticker.build();
};

async function gifToMp4(url) {
  const id = `${Date.now()}-${process.pid}`;
  const gifPath = path.join(tmp, `${id}.gif`);
  const mp4Path = path.join(tmp, `${id}.mp4`);

  try {
    const response = await axios({ url, responseType: "stream" });
    await new Promise((resolve, reject) => {
      const writer = fs.createWriteStream(gifPath);
      response.data.pipe(writer);
      writer.on("finish", resolve);
      writer.on("error", reject);
      response.data.on("error", reject);
    });

    await execAsync(
      `ffmpeg -i "${gifPath}" -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" -c:v libx264 -pix_fmt yuv420p "${mp4Path}"`,
    );
    return fs.readFileSync(mp4Path);
  } finally {
    for (const filePath of [gifPath, mp4Path]) {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
  }
}

async function uploadToCatbox(buffer) {
  const { ext, mime } = await fileTypeFromBuffer(buffer);
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", buffer, {
    filename: `${Date.now()}.${ext}`,
    contentType: mime,
  });

  const { data } = await axios.post(
    "https://catbox.moe/user/api.php",
    form,
    { headers: form.getHeaders() },
  );
  if (!data?.includes("catbox")) throw new Error("Upload failed");
  return data.trim();
}

async function AiChat(options = {}) {
  const text = encodeURIComponent(options.text || "");
  const model = encodeURIComponent(options.model || "openai");
  return (await fetch(`https://text.pollinations.ai/${text}?model=${model}`)).text();
}

const extractFromHtml = (html, baseUrl) => {
  const $ = cheerio.load(html);
  const selectors = [
    'meta[property="og:image"]',
    'meta[property="og:video"]',
    'meta[property="og:audio"]',
    'meta[name="twitter:image"]',
    'meta[name="twitter:player"]',
    'meta[name="twitter:video"]',
    'link[rel="image_src"]',
    'link[rel="video_src"]',
    "video source",
    "audio source",
    "img",
  ];

  for (const selector of selectors) {
    let url = $(selector).attr("content") || $(selector).attr("src") || $(selector).attr("href");
    if (url && !url.includes("base64") && !url.startsWith("data:")) {
      if (!url.startsWith("http")) {
        try {
          url = new URL(url, baseUrl).href;
        } catch {
          continue;
        }
      }
      if (url.match(/\.(jpg|jpeg|png|gif|webp|mp4|mkv|webm|mov|mp3|wav|ogg|m4a|flac)(\?|$)/i)) {
        return url;
      }
    }
  }
  return null;
};

const uploadToQuax = async (buffer) => {
  const { ext, mime } = await fileTypeFromBuffer(buffer);
  const form = new FormData();
  form.append("files[]", buffer, { filename: `tmp.${ext}`, contentType: mime });
  const { data } = await axios.post("https://qu.ax/upload.php", form, {
    headers: form.getHeaders(),
  });

  const mediaUrl =
    typeof data === "string"
      ? extractFromHtml(data, "https://qu.ax")
      : data.files?.[0]?.url;
  if (!mediaUrl) throw new Error("Upload failed");
  if (mediaUrl.includes("/x/")) return mediaUrl;

  const { data: pageHtml } = await axios.get(mediaUrl, {
    headers: { "User-Agent": "Mozilla/5.0" },
  });
  return extractFromHtml(pageHtml, mediaUrl) || mediaUrl;
};

async function uploadTmpfiles(buffer) {
  const apiKey = process.env.TERMAI_API_KEY;
  if (!apiKey) {
    throw new Error("This upload feature requires TERMAI_API_KEY in Replit Secrets.");
  }

  const { ext, mime } = await fileTypeFromBuffer(buffer);
  const form = new FormData();
  form.append("file", buffer, { filename: `file.${ext}`, contentType: mime });

  const uploadUrl = new URL("https://c.termai.cc/api/upload");
  uploadUrl.searchParams.set("key", apiKey);

  try {
    const response = await axios.post(uploadUrl.href, form, {
      headers: form.getHeaders(),
      timeout: 30000,
    });
    if (!response.data?.status || !response.data?.path) {
      throw new Error("Upload failed");
    }
    return response.data.path;
  } catch {
    throw new Error("Termai upload failed. Check the service and TERMAI_API_KEY.");
  }
}

export {
  uploadToCatbox,
  uploadToQuax,
  uploadTmpfiles,
  createSticker,
  AiChat,
  gifToMp4,
};