const fs = require('fs');
const path = require('path');

const img = "https://files.catbox.moe/pn8roe.jpg";

function walk(d) {
  let r = [];
  fs.readdirSync(d).forEach(f => {
    let p = path.join(d, f);
    if (fs.statSync(p).isDirectory()) {
      if (!p.includes("node_modules") && !p.includes(".git")) r = r.concat(walk(p));
    } else r.push(p);
  });
  return r;
}

walk(".").forEach(f => {
  if (f.endsWith(".js") && !f.includes("menu.js")) {
    let c = fs.readFileSync(f, "utf8");
    let u = c.replace(/(pp|thumb|thumbnail|menuImg|img)\s*:\s*["\']https?:\/\/[^"\']+["\']/g, '$1: "' + img + '"');
    if (c !== u) {
      fs.writeFileSync(f, u, "utf8");
      console.log("Updated: " + f);
    }
  }
});
