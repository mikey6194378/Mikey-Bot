import { Sticker } from "wa-sticker-formatter";

const run = async (m, { conn, text, command }) => {
  const [emojiOne, emojiTwo] = String(text || "").split("+");

  if (!(emojiOne && emojiTwo)) {
    return m.reply(
      `*⚠️ طـريـقـة الاسـتـخـدام:* \n- أرسل الأمر متبوعاً بإيموجيين بينهما علامة (+)\n\n*مثال:* \n\`.${command} 🗿+🔥\``,
    );
  }

  const apiKey = process.env.TENOR_API_KEY;
  if (!apiKey) {
    return m.reply("⚠️ ميزة دمج الإيموجي تحتاج إلى إعداد TENOR_API_KEY في أسرار Replit.");
  }

  try {
    const url = new URL("https://tenor.googleapis.com/v2/featured");
    url.searchParams.set("key", apiKey);
    url.searchParams.set("contentfilter", "high");
    url.searchParams.set("media_filter", "png_transparent");
    url.searchParams.set("component", "proactive");
    url.searchParams.set("collection", "emoji_kitchen_v5");
    url.searchParams.set("q", `${emojiOne.trim()}_${emojiTwo.trim()}`);

    const response = await fetch(url);
    if (!response.ok) throw new Error("Tenor request failed");
    const result = await response.json();

    if (!result.results?.length) {
      return m.reply("❌ هذا الدمج غير مدعوم في مطبخ الإيموجيات. جرّب دمجاً آخر.");
    }

    for (const item of result.results) {
      const sticker = await new Sticker(item.url, {
        type: "full",
        categories: item.tags,
        pack: "𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻",
        author: "𝑬𝑴𝑶𝑱𝑰 𝑴𝑰𝑿",
      }).toMessage();

      await conn.sendMessage(m.chat, sticker, { quoted: m });
    }
  } catch {
    await m.reply("❌ تعذر دمج الإيموجيات. تحقق من اتصال الخدمة وإعداد TENOR_API_KEY.");
  }
};

run.command = ["مكس", "ملصق-ايموجي", "emojimix"];
run.usage = ["مكس <ايموجي+ايموجي>"];
run.category = "sticker";
run.limit = true;

export default run;