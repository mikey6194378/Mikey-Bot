// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇
// ☃️ Plugin : بحث بينتريست فيديو
// ⚡ Bot : 𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻
// 🍷 Developer : 𝐴𝐻𝑀𝐸𝐷 𝐴𝐵𝑈𝐴𝐿𝐺𝐴𝑆𝐼𝑀
// ━ ╼╃ ⌬〔 𝑴𝑰𝑲𝑬𝒀 〕⌬ ╄╾ ━
// 120363397941013495@newsletter

import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'

const API_BASE = 'https://engez.a7a.online/api/v1'
const PINTEREST_ENDPOINT = `${API_BASE}/search/pinterest`
const FOOTER = '𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑩𝑶𝑻'
const MAX_CARDS = 3
const MAX_TRIED = 10
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'

const context = (jid) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363397941013495@newsletter',
        newsletterName: '𝑴𝑰𝑲𝑬𝒀 ┇🎴┇ 𝑪𝑯𝑨𝑵𝑵𝑬𝑳',
        serverMessageId: 0
    }
});

function shuffleArray(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function formatSize(bytes) {
  if (!bytes || bytes === 0) return '—'
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`
}

async function searchPins(query) {
  const apiUrl = `${PINTEREST_ENDPOINT}?action=${encodeURIComponent('بحث')}&q=${encodeURIComponent(query)}`
  const { data } = await axios.get(apiUrl, { timeout: 30000 })

  if (!data || data.success !== true) {
    throw new Error('فشل البحث في Pinterest')
  }

  const results = data.response?.results
  if (!Array.isArray(results) || results.length === 0) {
    throw new Error('لا توجد نتائج فيديو لهذا البحث')
  }

  return results
}

async function resolveDownloadUrl(pin) {
  const params = new URLSearchParams({ action: 'تحميل', pinUrl: pin.pin_url })
  if (pin.video_url) params.set('videoUrl', pin.video_url)
  if (pin.hls_url) params.set('hlsUrl', pin.hls_url)
  if (pin.video_signature) params.set('videoSignature', pin.video_signature)

  const apiUrl = `${PINTEREST_ENDPOINT}?${params.toString()}`
  const { data } = await axios.get(apiUrl, { timeout: 30000 })

  if (!data || data.success !== true || !data.response?.downloadUrl) {
    throw new Error(data?.error || 'فشل الحصول على رابط التحميل المباشر')
  }
  return data.response.downloadUrl
}

async function downloadVideoBuffer(url) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'user-agent': UA },
    timeout: 60000,
    maxRedirects: 5
  })
  return Buffer.from(res.data)
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const startDeco = `❐═━━━═╊⊰🎴⊱╉═━━━═❐`;
  const endDeco = `❐═━━━═╊⊰🎴⊱╉═━━━═❐`;

  if (!text) {
    return conn.sendMessage(m.chat, {
      text: `${startDeco}\n> *〔 طـريـقـة الـبـحـث 〕*\n\n*الـشـرح:* \n> *${usedPrefix}ايديت ناروتو*\n> *${usedPrefix}ايديت جوجو*\n\n${endDeco}`,
      contextInfo: context(m.sender)
    }, { quoted: m })
  }

  await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })
  
  let waitMsg;
  try {
    waitMsg = await conn.sendMessage(m.chat, {
      text: `${startDeco}\n> *〔 🔍 〕 جـاري الـبـحـث عـن إيـديـت ...*\n${endDeco}`,
      contextInfo: context(m.sender)
    }, { quoted: m });
  } catch (err) {}

  let pins
  try {
    pins = await searchPins(text)
  } catch (e) {
    try { await conn.sendMessage(m.chat, { delete: waitMsg.key }) } catch (err) {}
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return conn.sendMessage(m.chat, {
      text: `${startDeco}\n> *〔 ❌ 〕 ${e.message}*\n${endDeco}`,
      contextInfo: context(m.sender)
    }, { quoted: m })
  }

  try { await conn.sendMessage(m.chat, { delete: waitMsg.key }) } catch (e) {}
  
  let waitMsg2;
  try {
    waitMsg2 = await conn.sendMessage(m.chat, {
      text: `${startDeco}\n> *〔 ⏳ 〕 جـاري تـحـمـيـل الـفـيـديـوهـات ...*\n${endDeco}`,
      contextInfo: context(m.sender)
    }, { quoted: m });
  } catch (err) {}

  shuffleArray(pins)

  const cards = []
  let tried = 0

  for (let i = 0; i < pins.length && cards.length < MAX_CARDS; i++) {
    if (tried >= MAX_TRIED) break
    tried++
    const pin = pins[i]
    try {
      const downloadUrl = await resolveDownloadUrl(pin)
      const videoBuffer = await downloadVideoBuffer(downloadUrl)
      if (!videoBuffer || videoBuffer.length < 50000) continue

      const { videoMessage } = await prepareWAMessageMedia(
        { video: videoBuffer },
        { upload: conn.waUploadToServer }
      )

      const sizeText = formatSize(videoBuffer.length)
      const title = (pin.title || 'إيديت فخم').slice(0, 80)

      cards.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({ text: title }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `📦 ${sizeText} | ${FOOTER}` }),
        header: {
          title,
          hasMediaAttachment: true,
          videoMessage
        }
      })
    } catch (e) {
      console.error(`[pinterest-carousel] خطأ في معالجة Pin ${i}:`, e.message)
    }
  }

  try { await conn.sendMessage(m.chat, { delete: waitMsg2.key }) } catch (e) {}

  if (cards.length === 0) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return conn.sendMessage(m.chat, {
      text: `${startDeco}\n> *〔 ❌ 〕 لـم اتـمـكـن مـن تـحـمـيـل اي فـيـديـو، جـرب كـلـمـة اخـرى.*\n${endDeco}`,
      contextInfo: context(m.sender)
    }, { quoted: m })
  }

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            body: proto.Message.InteractiveMessage.Body.create({
              text: `${startDeco}\n> *〔 نـتـائـج الإيـديـت 〕*\n> *الشخصية:* ${text}\n${endDeco}`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: `📊 عـدد الـنـتـائـج: ${cards.length} | ${FOOTER}`
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
          },
          ...context(m.sender)
        }
      }
    },
    { userJid: conn.user.jid, quoted: m }
  )

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

handler.usage = ['ايديت <اسم الشخصية>'];
handler.category = 'search';
handler.command = ['ايديت', 'بينتر-فيديو', 'بينترف', 'pinterestvideo', 'pvv', 'بينتو'];

export default handler;
