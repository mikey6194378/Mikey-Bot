import yts from 'yt-search';
import fetch from 'node-fetch';

let handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) return m.reply(`*يرجى كتابة اسم الأغنية!*\nمثال: ${usedPrefix + command} سورة البقرة`);
  
  await m.reply('⏳ *جاري البحث وتحميل الأغنية، انتظر لحظة...*');

  try {
    let search = await yts(text);
    let vid = search.videos[0];
    if (!vid) return m.reply('❌ لم يتم العثور على أي نتائج!');

    let res = await fetch(`https://api.cobalt.tools/api/json`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        url: vid.url,
        downloadMode: 'audio',
        audioFormat: 'mp3'
      })
    });

    let data = await res.json();

    if (data.url) {
      await conn.sendMessage(m.chat, {
        audio: { url: data.url },
        mimetype: 'audio/mpeg',
        fileName: `${vid.title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: vid.title,
            body: vid.author.name,
            thumbnailUrl: vid.thumbnail,
            sourceUrl: vid.url,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });
    } else {
      // API احتياطي في حالة العطل
      let fallbackApi = `https://api.guruapi.tech/ytmp3?url=${encodeURIComponent(vid.url)}`;
      let fbRes = await fetch(fallbackApi);
      let fbData = await fbRes.json();
      
      await conn.sendMessage(m.chat, {
        audio: { url: fbData.result.download_url },
        mimetype: 'audio/mpeg',
        fileName: `${vid.title}.mp3`
      }, { quoted: m });
    }
  } catch (e) {
    console.error(e);
    m.reply('❌ حدث خطأ أثناء تحميل الملف، جرب مرة أخرى لاحقاً.');
  }
};

handler.help = ['play', 'song', 'اغنية', 'شغلي'];
handler.tags = ['downloader'];
handler.command = /^(play|song|اغنية|شغلي|تشغيل)$/i;

export default handler;
