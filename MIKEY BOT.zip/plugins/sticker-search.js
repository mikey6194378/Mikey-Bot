import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  // اقتطاع الاسم المباعوث بعد "ملصقات_"
  let query = text || command.replace(/^ملصقات_?/i, '');

  if (!query) throw `*يرجى كتابة الاسم بعد الشبيطة للبحث عن الملصقات!*\n\nمثال:\n*${usedPrefix}ملصقات_مايكي*`;

  await m.reply('🔍 *جاري البحث عن الملصقات وإرسالها...*');

  try {
    let res = await fetch(`https://api.shizo.tech/search/sticker?query=${encodeURIComponent(query)}&apikey=shizo`);
    let json = await res.json();

    if (!json || !json.result || json.result.length === 0) {
      let altRes = await fetch(`https://api.lolhuman.xyz/api/stickerwa?query=${encodeURIComponent(query)}&apikey=Gatito`);
      let altJson = await altRes.json();
      if (altJson && altJson.result) json = { result: altJson.result };
    }

    if (!json || !json.result || json.result.length === 0) {
      return m.reply('❌ لم أتمكن من العثور على ملصقات بهذا الاسم.');
    }

    let stickers = json.result.slice(0, 10);

    for (let st of stickers) {
      let stUrl = typeof st === 'string' ? st : (st.url || st.sticker);
      if (stUrl) {
        await conn.sendFile(m.chat, stUrl, 'sticker.webp', '', m, false, { asSticker: true });
      }
    }
  } catch (e) {
    console.error(e);
    m.reply('❌ حدث خطأ أثناء إحضار الملصقات.');
  }
};

// الشرح والتسجيل داخل قائمة .اوامر و .شرح في قسم الملصقات
handler.help = ['ملصقات_<الاسم>'];
handler.tags = ['sticker'];
handler.command = /^ملصقات_(.+)$/i;

export default handler;
