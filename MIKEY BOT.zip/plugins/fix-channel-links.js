// ميزة للتأكد من سلامة روابط القنوات المحولة
let handler = m => m;

handler.all = async function (m) {
  if (m.text && m.text.includes('whatsapp.com/channel/')) {
    // تنظيف وتثبيت رابط القناة حتى لا يتشوه عند التوجيه
    m.text = m.text.replace(/(https?:\/\/chat\.whatsapp\.com\/[^\s]+)/g, '$1');
  }
};

export default handler;
