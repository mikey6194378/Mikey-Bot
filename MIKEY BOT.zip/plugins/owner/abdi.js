let handler = async (m, { conn }) => {
  if (m.text && m.text.trim() === 'عبدي') {
    if (m.sender.includes("201508431390")) {
      await m.reply('امــرك ســيـدي الـمـطـور 🙏👑');
    }
  }
};

handler.customPrefix = /^(عبدي)$/i;
handler.command = new RegExp('^عبدي$', 'i');

export default handler;
