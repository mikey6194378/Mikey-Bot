const test = async (m, { conn, bot }) => {
  m.react("🟢")
  
  conn.msgUrl(m.chat, "♡𝑺𝑻𝑶𝑷𝑰𝑵𝑮 𝑻𝑯𝑬 𝑩𝑶𝑻", { 
    title: "𝑴𝑰𝑲𝑬𝒀 𝑰𝑺 𝑺𝑻𝑶𝑷𝑰𝑵𝑮 ⛔",
    body: "𝑻𝑯𝑬 𝑩𝑶𝑻 𝑰𝑺 𝑺𝑻𝑶𝑷𝑰𝑵𝑮",
    img: "https://files.catbox.moe/pn8roe.jpg",
    big: false 
  });
  
  setTimeout(() => {
    bot.stop();
  }, 1000); 
};

test.category = "owner";
test.command = ["ايقاف", "stop"];
test.owner = true;
export default test;