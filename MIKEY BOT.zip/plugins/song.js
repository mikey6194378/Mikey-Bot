import yts from 'yt-search';
import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*يرجى كتابة اسم الأغنية أو المقطع!*\n\nمثال:\n*${usedPrefix + command} سورة الكهف*`;

  await m.reply('🔍 *جاري البحث وتحميل المقطع الصوتي، يرجى الانتظار قليلاً...*');

  try {
    let search = await yts(text);
    let vid = search.videos[0];
    if (!vid) return m.reply('❌ لم أتمكن من العثور على أي نتائج مطابقة.');

    let { title, thumbnail, timestamp, views, url } = vid;

    let info = `🎵 *العنوان:* ${title}\n⏱️ *المدة:* ${timestamp}\n👁️ *المشاهدات:* ${views}\n🔗 *الرابط:* ${url}\n\n*جاري إرسال المقطع الصوتي 🎧...*`;
    await conn.sendFile(m.chat, thumbnail, 'thumb.jpg', info, m);

    let audioUrl;
    
    // المحاولة الأولى (سيرفر Shizo)
    try {
      let res = await fetch(`https://api.shizo.tech/api/downloader/ytmp3?url=${encodeURIComponent(url)}&apikey=shizo`);
      let json = await res.json();
      if (json && json.data && json.data.url) audioUrl = json.data.url;
    } catch (e) { console.error('API 1 Error'); }

    // المحاولة الثانية (سيرفر Lolhuman) في حال فشل الأول
    if (!audioUrl) {
      try {
        let res2 = await fetch(`https://api.lolhuman.xyz/api/ytaudio2?url=${encodeURIComponent(url)}&apikey=Gatito`);
        let json2 = await res2.json();
        if (json2 && json2.result && json2.result.link) audioUrl = json2.result.link;
      } catch (e) { console.error('API 2 Error'); }
    }

    // المحاولة الثالثة (سيرفر AEMT)
    if (!audioUrl) {
        try {
            let res3 = await fetch(`https://aemt.me/download/ytdl?url=${encodeURIComponent(url)}`);
            let json3 = await res3.json();
            if (json3 && json3.result && json3.result.mp3) audioUrl = json3.result.mp3;
        } catch(e) { console.error('API 3 Error'); }
    }

    if (!audioUrl) return m.reply('❌ عذراً، فشل التحميل من جميع السيرفرات حالياً. يرجى المحاولة بعد قليل أو تجربة مقطع آخر.');

    // إرسال الصوت كرسالة صوتية (Audio)
    await conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg' }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply('❌ حدث خطأ داخلي أثناء معالجة الطلب.');
  }
};

// إعدادات ظهور الأمر في القوائم والشرح
handler.help = ['اغنية <الاسم>'];
handler.tags = ['downloader']; // سيظهر في قسم التحميل
handler.command = /^(اغنية|اغنيه|موسيقى|شغل)$/i;

export default handler;
